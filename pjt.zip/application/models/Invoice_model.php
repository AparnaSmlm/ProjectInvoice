<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Invoice_model extends CI_Model {
	
	public function add_data($data,$table) {
		if($this->insert_to($table, $data)) {
			foreach($data as $key =>$val) {
				$data[$key] = '';
			}
			unset($_POST);
			$data['timeout'] = true;
			$data['time_out'] = true;
			$data['resultmsg'] = '<div class="alert alert-success" >Added Successfully</div>';
		}
		else {
			$data['resultmsg'] = '<div class="alert alert-danger" >Try again..</div>';
		}
		
		return $data;
	}
	 
	 public function get_data($table) {
		$this->db->select('*');
		$query = $this->db->get($table); 
		$res=$query->result_array();

				return $res;

    }
	function delete_from($table,$where) {
		
		if($this->db->delete($table, $where)) {
				$data['resultmsg'] = '<div class="alert alert-success">Deleted Successfully</div>';
				
			}return $data;
	}
	
	
	function insert_to($table, $data) {
		$data = $this->security->xss_clean($data);
		if($this->db->insert($table, $data)) {
			return true;
		}
		return false;
	}
	
	function update_value($table,$where,$data) {
		$data = $this->security->xss_clean($data);
		if($this->db->update($table, $data, $where)) {
			return true;
		}
		else
		return false;
	}
	
	public function edit_data($data,$table,$where) {
		$this->update_value($table,$where,$data);
			
			
		return $data;
	}
}