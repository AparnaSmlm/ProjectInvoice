<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	// 	 define('BASE_URL', 'http://localhost/pjt');

 public function __construct(){
        parent::__construct();
		$this->load->helper('url'); 
		$this->load->model('Invoice_model'); 

      }
	  
	public function db()
	{
		if ( $this->load->database() === FALSE )
{
  echo"no";
} else { echo "ok";}
	} 
	public function index()
	{ 
		$data['res'] = $this->Invoice_model->get_data('data_invoice');
 		$this->load->view('invoice',$data);
		
	}public function delete_data()
	{
		$id=$this->input->post('id');
		$where=['id'=>$id];
        $data = $this->Invoice_model->delete_from('data_invoice',$where);
		echo $data['resultmsg'];
		exit;
	}
	public function add_data()
	{
		$data['name']=$this->input->post('name');
		$data['quantity']=$this->input->post('quantity');
		$data['price']=$this->input->post('price');
		$data['tax']=$this->input->post('tax');
		$data['line_total']=$this->input->post('linetotal');
		$data['discount']=$this->input->post('discount');
		
		 
		$data= $this->Invoice_model->add_data($data,'data_invoice');
		 echo $data['resultmsg'] ;exit;
	}
	public function test()
	{
		$this->load->view('test');
	}
	public function pdf()
	{
 		$data['res'] = $this->Invoice_model->get_data('data_invoice');
 		$this->load->view('pdf',$data);
 	}
		public function pdfn()
	{ 
		$data['res'] = $this->Invoice_model->get_data('data_invoice');
 		$this->load->view('pdf',$data);
         
        // Get output html
        $html = $this->output->get_output();
        
        // Load pdf library
        $this->load->library('pdf');
        
        // Load HTML content
        $this->dompdf->loadHtml($html);
        
        // (Optional) Setup the paper size and orientation
        $this->dompdf->setPaper('A4', 'landscape');
        
        // Render the HTML as PDF
        $this->dompdf->render();
        
        // Output the generated PDF (1 = download and 0 = preview)
        $this->dompdf->stream("welcome.pdf", array("Attachment"=>0));
    }
  
	
	public function update()
	{
		 $data['discount']=$this->input->post('discount');
		$data['total']=$this->input->post('total');
		$data['res'] = $this->Invoice_model->edit_data($data,'data_invoice',[]);
		echo $this->db->last_query();
 	}
}
