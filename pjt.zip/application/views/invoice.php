<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Project | Dashboard</title>
	 <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicon.png">

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/dist/css/adminlte.min.css">
  <!-- summernote -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/summernote/summernote-bs4.min.css">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
     
     
    </ul>

   
    

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto"> 
    </ul>
  </nav>  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php $this->load->view('sidebar');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
<div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Invoice</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="">Home</a></li>
              <li class="breadcrumb-item active">Invoice</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-outline card-info">
			  <div id="resultdiv" ></div>
             <div class="card-header">
              <h3 class="card-title">
               </h3>
              <!-- tools box -->
             
              <!-- /. tools -->
            </div>
            <!-- /.card-header --> <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
			  <script>
			  
			  
	  
	  
	    //delete row
function delete_row(no)
{   
	$.ajax({
                type:'POST',
                url:'<?php echo base_url("admin/delete_data"); ?>',
                data:{'id':no},
                success:function(data){
				 				    $("#divid").load(" #divid");

                    $('#resultdiv').html(data);calcdisc();
                }
            });
 }

  //add row
function add_row()
{ 
 	var discountval =  $('#discount').val();


 var name=document.getElementById("name").value;
 if(name=='') { alert("Enter Name");  return false; }
 var quantity=document.getElementById("quantity").value;
  if(quantity=='') { alert("Enter quantity"); return false;}

 var price=document.getElementById("price").value;
  if(price=='') { alert("Enter price"); return false; }

 var tax=document.getElementById("tax").value;
 //alert(tax);
  if(tax==' ') { alert("Enter tax"); return false; }
  if(tax==0)
  {
	var  linetotal=quantity*price;
  } else {
 var taxval=parseFloat((quantity*price*(tax/100)));
 var linetotal=parseFloat((quantity*price)+taxval);
  }
 

$.ajax({
                type:'POST',
                url:'<?php echo base_url("admin/add_data"); ?>',
                data:{'name':name,'quantity':quantity,'price':price,'tax':tax,'linetotal':linetotal,'discount':discountval},
                success:function(data){
				    $("#divid").load(" #divid");
                    $('#resultdiv').html(data);
 					calcdisc();
					
			
			
                }
            });
			
 

 document.getElementById("name").value="";
 document.getElementById("quantity").value="";
 document.getElementById("price").value="";
 document.getElementById("tax").value="";
}
 function calcdisc()
 { 
	 var total=0;
	var discountval =  $('#discount').val();
	var taxsum =  $("#taxsum").text();  
	var valuein = $('#inval').find(":selected").text();//$,%

	if(valuein=='$')
	{
		 
		total=taxsum-discountval;	 

	}
	else
	{
        total=taxsum-(taxsum*(discountval/100));
	}
	 $('#totalval').html(total);
	 
	 

$.ajax({
                type:'POST',
                url:'<?php echo base_url("admin/update"); ?>',
                data:{'discount':discountval,'total':total},
                success:function(data){
				 //  alert("dsf");
                }
            });
			
 
   } 
</script>
       <style>
         th, td {
            border: 1px solid black;
			width:170px;
			
         }
      </style>   <style>
        input[type="text"] {
     width:170px;  
}
      </style>    
              <div class="col-md-12">
<table align='center'  style="width: -moz-available; "   cellspacing=0 cellpadding=10 id="test">

 
  <tr id="row" > 
<td style="width:150px;"><input type="text"  placeholder="Enter Name"   id="name"></td>
<td><input type="text" placeholder="Enter Quantity" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" id="quantity" name="quantity" ></td>

<td><input type="text"  placeholder="Enter Price"oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" id="price"></td>
<td><select id="tax">
<option   id=" ">Select tax</option>
<option id="0">0</option>
<option id="1">1</option>
<option id="5">5</option>
<option id="10">10</option></select></td>
<td><input type="button" class="add" onclick="add_row();" value="Add Row"></td>
 </tr>
 
</table>
<br>
		
<div id="divid">    <h2 style="text-align: center;"><strong>Particulars</strong></h2>
<table align='center' rowspan="4" cellspacing=6 cellpadding=10 id="data_table" border=1>
<tr>
<th>Name</th>
<th>Quantity</th>
<th>Unit Price</th>
<th>Tax(%)</th>
<th>Line Total</th>
</tr>
  
  
  <?php   $i=1;$sum=0;$subtot=0; $discount=0;$total=0;
 foreach($res  as $row) 
{
 ?>

<tr id="row<?php echo $row['id'];?>" >
<td> <?php echo $row['name'];?></td>
<td> <?php echo $row['quantity'];?></td>
<td> <?php echo $row['price'];?></td>
<td> <?php echo $row['tax'];?></td>
<td> <?php echo $row['line_total'];?></td>
<td><input type="button" class="add" onclick="delete_row(<?php echo $row['id'];?>)" value="Delete"></td>

</tr>
 
<?php $i++;
$subtot=($row['quantity']*$row['price'])+$subtot;
 $total= $row['total'];;
 $discount= $row['discount'];;
$sum=$row['line_total']+$sum; 
} ?>
 
		
<tr>
  
     <td    style="text-align: right;"colspan="4">Subtotal</td>
     <td  colspan="2"><?php echo $subtot;?></td>
</tr> 
<tr>
  
     <td    style="text-align: right;"colspan="4">Subtotal with tax</td>
     <td  id="taxsum" colspan="2"><?php echo $sum;?>	</td>
 </tr>
 
<tr>
  
     <td    style="text-align: right;"colspan="4">Discount</td>
     <td  colspan="2"><select id="inval" onchange="calcdisc()"><option value="1">$</option><option value="2">%</option><input type="text"  id="discount"  value="<?php echo $discount;?>"onkeyup="calcdisc()"></td>
	
</tr> 
<tr>
  
     <td    style="text-align: right;"colspan="4">  <button  class="btn btn-primary"  onclick="calcdisc()">Calculate Total</button></td>
     <td id="totalval" colspan="2"><?php echo $total;?>	</td>
</tr> 
</table>
 <br>





</div>

</body>
 

		  


  
             
            </div>
				  
				  <div class="card-footer">

    <button class="btn btn-primary" onclick="location.href='<?php echo base_url();?>admin/generatepdf'">Generate Pdf</button>
               
				  
				    </div>
          </div>
        </div>
        <!-- /.col-->
      </div>
      <!-- ./row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
   <?php $this->load->view('footer');?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url();?>assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url();?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url();?>assets/dist/js/demo.js"></script>
<!-- Summernote -->
<script src="<?php echo base_url();?>assets/plugins/summernote/summernote-bs4.min.js"></script>
<script>
  $(function () {
    // Summernote
    $('.textarea').summernote()
  })
</script>
</body>
</html>
